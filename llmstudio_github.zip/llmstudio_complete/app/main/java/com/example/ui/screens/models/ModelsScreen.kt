package com.example.ui.screens.models

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*

data class ModelCard(
    val id: String,
    val name: String,
    val provider: String,
    val size: String,
    val ramNeeded: String,
    val description: String,
    val isFree: Boolean,
    val isCloud: Boolean,
    val tags: List<String>,
    val providerColor: Color,
)

val CLOUD_MODELS = listOf(
    ModelCard("gemini-2.5-flash","Gemini 2.5 Flash","gemini","Cloud","0 MB","Fast, smart, free. Best for everyday tasks.",true,true, listOf("Free","Fast","Smart"), Color(0xFF4285F4)),
    ModelCard("gemini-1.5-pro","Gemini 1.5 Pro","gemini","Cloud","0 MB","Google's most capable model. 1M context.",true,true, listOf("Free","1M ctx","Pro"), Color(0xFF4285F4)),
    ModelCard("llama-3.1-8b-instant","Llama 3.1 8B Instant","groq","Cloud","0 MB","Blazing fast. Best free option for speed.",true,true, listOf("Free","Ultra fast"), Color(0xFFF55036)),
    ModelCard("llama-3.3-70b-versatile","Llama 3.3 70B","groq","Cloud","0 MB","Most powerful free model. Near GPT-4 quality.",true,true, listOf("Free","Powerful"), Color(0xFFF55036)),
    ModelCard("mixtral-8x7b-32768","Mixtral 8x7B","groq","Cloud","0 MB","32K context. Great for long documents.",true,true, listOf("Free","32K ctx"), Color(0xFFF55036)),
    ModelCard("meta-llama/llama-3.2-3b-instruct:free","Llama 3.2 3B Free","openrouter","Cloud","0 MB","Free via OpenRouter. Good balance.",true,true, listOf("Free","OpenRouter"), Color(0xFF6366F1)),
    ModelCard("deepseek/deepseek-r1:free","DeepSeek R1 Free","openrouter","Cloud","0 MB","Reasoning model. Free via OpenRouter.",true,true, listOf("Free","Reasoning"), Color(0xFF6366F1)),
    ModelCard("gpt-4o-mini","GPT-4o Mini","openai","Cloud","0 MB","OpenAI's fast affordable model.",false,true, listOf("Paid","Fast"), Color(0xFF10A37F)),
    ModelCard("deepseek-chat","DeepSeek Chat","deepseek","Cloud","0 MB","Powerful and very affordable.",false,true, listOf("Cheap","Smart"), Color(0xFF4A90E2)),
    ModelCard("claude-haiku-4-5-20251001","Claude Haiku","anthropic","Cloud","0 MB","Anthropic's fast model.",false,true, listOf("Paid","Fast"), Color(0xFFD4A27F)),
)

val LOCAL_MODELS = listOf(
    ModelCard("llama-3.2-1b","Llama 3.2 1B","local","700 MB","1.2 GB","Best for 2-3 GB RAM. Fast & capable.",true,false, listOf("1B","Fast","Low RAM"), Color(0xFF7C3AED)),
    ModelCard("qwen2.5-0.5b","Qwen 2.5 0.5B","local","340 MB","800 MB","Minimum RAM device. Tiny but works.",true,false, listOf("0.5B","Ultra light"), Color(0xFF7C3AED)),
    ModelCard("smollm2-1.7b","SmolLM2 1.7B","local","1.0 GB","1.5 GB","Very fast. HuggingFace's tiny model.",true,false, listOf("1.7B","Fast"), Color(0xFF7C3AED)),
    ModelCard("phi-3.5-mini","Phi 3.5 Mini","local","2.2 GB","3.0 GB","Microsoft. Best reasoning for size.",true,false, listOf("3.8B","Reasoning"), Color(0xFF7C3AED)),
    ModelCard("gemma-2-2b","Gemma 2 2B","local","1.6 GB","2.3 GB","Google's efficient small model.",true,false, listOf("2B","Google"), Color(0xFF7C3AED)),
    ModelCard("llama-3.2-3b","Llama 3.2 3B","local","1.8 GB","2.5 GB","Best for 4 GB RAM. Great quality.",true,false, listOf("3B","Balanced"), Color(0xFF7C3AED)),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelsScreen() {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Cloud", "Local")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.SmartToy, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                        Text("Models", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                tabs.forEachIndexed { i, label ->
                    Tab(
                        selected = tab == i,
                        onClick  = { tab = i },
                        text     = { Text(label, fontWeight = if (tab == i) FontWeight.SemiBold else FontWeight.Normal) }
                    )
                }
            }
            when (tab) {
                0 -> CloudModelsList()
                1 -> LocalModelsList()
            }
        }
    }
}

@Composable
private fun CloudModelsList() {
    var filterFree by remember { mutableStateOf(false) }
    Column {
        Row(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filterFree, onClick = { filterFree = !filterFree }, label = { Text("Free only") }, leadingIcon = if (filterFree) { { Icon(Icons.Filled.Check, null, Modifier.size(14.dp)) } } else null)
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val list = if (filterFree) CLOUD_MODELS.filter { it.isFree } else CLOUD_MODELS
            items(list, key = { it.id }) { model ->
                ModelItem(model, isLocal = false)
            }
        }
    }
}

@Composable
private fun LocalModelsList() {
    Column {
        Surface(modifier = Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer) {
            Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary)
                Column {
                    Text("Local AI (Coming Soon)", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Text("Download GGUF models to run AI completely offline without internet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(LOCAL_MODELS, key = { it.id }) { model ->
                ModelItem(model, isLocal = true)
            }
        }
    }
}

@Composable
private fun ModelItem(model: ModelCard, isLocal: Boolean) {
    var expanded by remember { mutableStateOf(false) }
    Card(
        onClick = { expanded = !expanded },
        shape   = RoundedCornerShape(14.dp),
        colors  = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border  = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(shape = RoundedCornerShape(8.dp), color = model.providerColor.copy(alpha = 0.12f), modifier = Modifier.size(38.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            if (isLocal) Icons.Filled.Storage else Icons.Filled.Cloud,
                            null, tint = model.providerColor, modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(model.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        model.tags.take(3).forEach { tag ->
                            Surface(shape = RoundedCornerShape(4.dp), color = model.providerColor.copy(alpha = 0.1f)) {
                                Text(tag, modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp), style = MaterialTheme.typography.labelSmall, color = model.providerColor, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(model.size, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (model.isFree) Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFF16A34A).copy(alpha = 0.12f)) {
                        Text("Free", modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp), style = MaterialTheme.typography.labelSmall, color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                    }
                }
            }
            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HorizontalDivider()
                    Text(model.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (isLocal) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {}, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Filled.Download, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Download")
                            }
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("RAM needed: ${model.ramNeeded}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Filled.CheckCircle, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Select This Model")
                        }
                    }
                }
            }
        }
    }
}
