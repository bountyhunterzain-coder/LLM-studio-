package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary            = BrandPurple,
    onPrimary          = Color.White,
    primaryContainer   = BrandPurplePale,
    onPrimaryContainer = BrandPurple,
    secondary          = BrandPurpleLight,
    onSecondary        = Color.White,
    secondaryContainer = BrandPurplePale,
    onSecondaryContainer = BrandPurple,
    tertiary           = BrandPurpleLight,
    onTertiary         = Color.White,
    background         = LightBackground,
    onBackground       = LightTextMain,
    surface            = LightSurface,
    onSurface          = LightTextMain,
    surfaceVariant     = LightSurface2,
    onSurfaceVariant   = LightTextSub,
    outline            = LightBorder,
    outlineVariant     = LightDivider,
    error              = ColorError,
    onError            = Color.White,
    errorContainer     = ColorErrorBg,
    onErrorContainer   = ColorError,
)

private val DarkColors = darkColorScheme(
    primary            = BrandPurpleDark,
    onPrimary          = Color.Black,
    primaryContainer   = Color(0xFF3B1F6E),
    onPrimaryContainer = BrandPurpleDark,
    secondary          = BrandPurpleDark,
    onSecondary        = Color.Black,
    secondaryContainer = Color(0xFF2D2442),
    onSecondaryContainer = BrandPurpleDark,
    tertiary           = BrandPurpleDark,
    onTertiary         = Color.Black,
    background         = DarkBackground,
    onBackground       = DarkTextMain,
    surface            = DarkSurface,
    onSurface          = DarkTextMain,
    surfaceVariant     = DarkSurface2,
    onSurfaceVariant   = DarkTextSub,
    outline            = DarkBorder,
    outlineVariant     = DarkDivider,
    error              = Color(0xFFFF7B72),
    onError            = Color.Black,
    errorContainer     = Color(0xFF3D0000),
    onErrorContainer   = Color(0xFFFF7B72),
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography  = Typography,
        content     = content
    )
}
