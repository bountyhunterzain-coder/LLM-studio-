package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.*
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.models.ModelsScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.terminal.TerminalScreen

sealed class Screen(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Home     : Screen("home",     "Chats",    Icons.Filled.ChatBubble,     Icons.Outlined.ChatBubbleOutline)
    object Models   : Screen("models",   "Models",   Icons.Filled.SmartToy,       Icons.Outlined.SmartToy)
    object Terminal : Screen("terminal", "Terminal", Icons.Filled.Terminal,        Icons.Filled.Terminal)
    object Settings : Screen("settings", "Settings", Icons.Filled.Settings,        Icons.Outlined.Settings)
}

private val navItems = listOf(Screen.Home, Screen.Models, Screen.Terminal, Screen.Settings)

@Composable
fun MainAppScreen() {
    val navController = rememberNavController()
    val backStack     by navController.currentBackStackEntryAsState()
    val current       = backStack?.destination
    val showNav       = navItems.any { it.route == current?.route }

    Scaffold(
        bottomBar = {
            AnimatedVisibility(
                visible = showNav,
                enter   = slideInVertically { it } + fadeIn(),
                exit    = slideOutVertically { it } + fadeOut()
            ) {
                NavigationBar(tonalElevation = 0.dp) {
                    navItems.forEach { screen ->
                        val selected = current?.hierarchy?.any { it.route == screen.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick  = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState    = true
                                }
                            },
                            icon  = {
                                Icon(
                                    if (selected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.label
                                )
                            },
                            label = {
                                Text(screen.label, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                            },
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController    = navController,
            startDestination = Screen.Home.route,
            modifier         = Modifier.padding(padding),
            enterTransition  = { fadeIn() + slideInHorizontally { 60 } },
            exitTransition   = { fadeOut() + slideOutHorizontally { -60 } },
            popEnterTransition  = { fadeIn() + slideInHorizontally { -60 } },
            popExitTransition   = { fadeOut() + slideOutHorizontally { 60 } },
        ) {
            composable(Screen.Home.route)     { HomeScreen(onNavigateToChat = { navController.navigate("chat/$it") }) }
            composable(Screen.Models.route)   { ModelsScreen() }
            composable(Screen.Terminal.route) { TerminalScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
            composable(
                route = "chat/{chatId}",
                arguments = listOf(navArgument("chatId") { type = NavType.StringType })
            ) { back ->
                ChatScreen(
                    chatId          = back.arguments?.getString("chatId") ?: "",
                    onNavigateBack  = { navController.popBackStack() }
                )
            }
        }
    }
}
