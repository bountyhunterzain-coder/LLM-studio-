package com.example.ui.screens.home

import android.app.Application
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getDatabase(app).chatDao()
    val chats = dao.getAllChats()

    fun newChat(onCreated: (String) -> Unit) = viewModelScope.launch {
        val id = UUID.randomUUID().toString()
        dao.insertChat(ChatEntity(id = id, title = "New Chat", updatedAt = System.currentTimeMillis()))
        onCreated(id)
    }

    fun deleteChat(chatId: String) = viewModelScope.launch {
        dao.deleteChat(chatId)
        dao.deleteMessagesForChat(chatId)
    }

    fun pinChat(chatId: String, pinned: Boolean) = viewModelScope.launch {
        dao.pinChat(chatId, pinned)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToChat: (String) -> Unit,
    vm: HomeViewModel = viewModel()
) {
    val chats by vm.chats.collectAsState(initial = emptyList())
    var deleteTarget by remember { mutableStateOf<String?>(null) }

    // Delete confirmation dialog
    deleteTarget?.let { chatId ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            icon    = { Icon(Icons.Filled.DeleteOutline, null, tint = MaterialTheme.colorScheme.error) },
            title   = { Text("Delete Chat?") },
            text    = { Text("This conversation will be permanently deleted.") },
            confirmButton = {
                TextButton(
                    onClick  = { vm.deleteChat(chatId); deleteTarget = null },
                    colors   = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                        Text("LLM Studio", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    }
                },
                actions = {
                    IconButton(onClick = { vm.newChat(onNavigateToChat) }) {
                        Icon(Icons.Filled.EditNote, "New Chat")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        if (chats.isEmpty()) {
            EmptyState(onNewChat = { vm.newChat(onNavigateToChat) }, modifier = Modifier.padding(padding))
        } else {
            LazyColumn(
                modifier            = Modifier.fillMaxSize().padding(padding),
                contentPadding      = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                items(chats, key = { it.id }) { chat ->
                    ChatRow(
                        chat       = chat,
                        onClick    = { onNavigateToChat(chat.id) },
                        onDelete   = { deleteTarget = chat.id },
                        onPin      = { vm.pinChat(chat.id, !chat.isPinned) },
                    )
                    HorizontalDivider(modifier = Modifier.padding(start = 72.dp), thickness = 0.5.dp)
                }
            }
        }
    }
}

@Composable
private fun ChatRow(chat: ChatEntity, onClick: () -> Unit, onDelete: () -> Unit, onPin: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Surface(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            color    = MaterialTheme.colorScheme.background
        ) {
            Row(
                modifier            = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment   = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Avatar
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        if (chat.isPinned)
                            Icon(Icons.Filled.PushPin, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        else
                            Icon(Icons.Outlined.ChatBubbleOutline, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    }
                }
                // Text
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        chat.title,
                        fontWeight = FontWeight.SemiBold,
                        style      = MaterialTheme.typography.bodyLarge,
                        maxLines   = 1,
                        overflow   = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        ProviderChip(chat.provider)
                        Text(
                            formatTime(chat.updatedAt),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (chat.messageCount > 0) {
                            Text(
                                "· ${chat.messageCount} msgs",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                // More button
                Box {
                    IconButton(onClick = { expanded = true }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.MoreVert, null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        DropdownMenuItem(
                            text = { Text(if (chat.isPinned) "Unpin" else "Pin") },
                            leadingIcon = { Icon(Icons.Filled.PushPin, null) },
                            onClick = { onPin(); expanded = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Filled.DeleteOutline, null, tint = MaterialTheme.colorScheme.error) },
                            onClick = { onDelete(); expanded = false }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProviderChip(provider: String) {
    val (label, color) = when (provider) {
        "groq"       -> "Groq"       to Color(0xFFF55036)
        "openai"     -> "OpenAI"     to Color(0xFF10A37F)
        "anthropic"  -> "Claude"     to Color(0xFFD4A27F)
        "deepseek"   -> "DeepSeek"   to Color(0xFF4A90E2)
        "openrouter" -> "Router"     to Color(0xFF6366F1)
        else         -> "Gemini"     to Color(0xFF4285F4)
    }
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = color.copy(alpha = 0.12f),
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
            style    = MaterialTheme.typography.labelSmall,
            color    = color,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun EmptyState(onNewChat: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(80.dp)
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.AutoAwesome, null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
                }
            }
            Text("Welcome to LLM Studio", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "Run AI locally or connect to cloud providers. Start your first conversation.",
                style   = MaterialTheme.typography.bodyMedium,
                color   = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.widthIn(max = 280.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Button(
                onClick = onNewChat,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("New Conversation")
            }
        }
    }
}

private fun formatTime(millis: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - millis
    return when {
        diff < 60_000        -> "Just now"
        diff < 3_600_000     -> "${diff / 60_000}m ago"
        diff < 86_400_000    -> "${diff / 3_600_000}h ago"
        diff < 604_800_000   -> "${diff / 86_400_000}d ago"
        else                 -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(millis))
    }
}
