package com.example.ui.screens.chat

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

// ── ViewModel ────────────────────────────────────────────────

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao      = AppDatabase.getDatabase(app).chatDao()
    private val settings = SettingsRepository(app)

    private val _generating = MutableStateFlow(false)
    val generating: StateFlow<Boolean> = _generating

    private val _currentSettings = MutableStateFlow(AppSettings())
    val currentSettings: StateFlow<AppSettings> = _currentSettings

    private val _statusText = MutableStateFlow("")
    val statusText: StateFlow<String> = _statusText

    private var generationJob: Job? = null

    init {
        viewModelScope.launch {
            settings.settings.collect { _currentSettings.value = it }
        }
    }

    fun getMessages(chatId: String) = dao.getMessagesForChat(chatId)

    fun stopGeneration() {
        generationJob?.cancel()
        _generating.value = false
        _statusText.value = ""
    }

    fun sendMessage(chatId: String, text: String) {
        generationJob = viewModelScope.launch {
            _generating.value = true
            _statusText.value = "Thinking..."

            // Save user message
            val userMsg = MessageEntity(chatId = chatId, role = "user", content = text)
            dao.insertMessage(userMsg)

            // Save typing placeholder
            val typingId = dao.insertMessage(MessageEntity(chatId = chatId, role = "assistant", content = "▋"))

            try {
                val cfg       = _currentSettings.value
                val apiKey    = settings.getKeyForProvider(cfg, cfg.provider)
                val history   = dao.getMessagesForChatSync(chatId).dropLast(1) // exclude typing

                _statusText.value = "Generating..."
                val t0   = System.currentTimeMillis()
                val reply = AiClient.chat(
                    provider     = cfg.provider,
                    model        = cfg.model,
                    apiKey       = apiKey,
                    messages     = history,
                    systemPrompt = cfg.systemPrompt,
                    temperature  = cfg.temperature.toDouble(),
                    maxTokens    = cfg.maxTokens
                )
                val ms = System.currentTimeMillis() - t0

                // Replace typing message with real reply
                dao.updateMessageContent(typingId.toInt(), reply)

                // Update title if first message
                val count = dao.getMessageCount(chatId)
                if (count <= 2) {
                    val title = text.take(40).trim()
                    dao.updateChatTitle(chatId, title)
                }
                dao.updateMessageCount(chatId, count)
                _statusText.value = "${ms / 1000.0f}s"
                delay(2000)
                _statusText.value = ""
            } catch (e: CancellationException) {
                dao.updateMessageContent(typingId.toInt(), "[Generation stopped]")
            } catch (e: Exception) {
                val err = when {
                    e.message?.contains("401") == true -> "❌ Invalid API key. Set your key in Settings."
                    e.message?.contains("429") == true -> "❌ Rate limit exceeded. Try again in a moment."
                    e.message?.contains("timeout") == true -> "❌ Request timed out. Check your connection."
                    e.message?.contains("key") == true -> "❌ API key missing. Go to Settings → API Keys."
                    else -> "❌ Error: ${e.message}"
                }
                dao.updateMessageContent(typingId.toInt(), err)
            } finally {
                _generating.value = false
                _statusText.value = ""
            }
        }
    }
}

// ── Screen ───────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chatId: String,
    onNavigateBack: () -> Unit,
    vm: ChatViewModel = viewModel()
) {
    val messages    by vm.getMessages(chatId).collectAsState(initial = emptyList())
    val generating  by vm.generating.collectAsState()
    val statusText  by vm.statusText.collectAsState()
    val settings    by vm.currentSettings.collectAsState()
    val listState       = rememberLazyListState()
    val haptic          = LocalHapticFeedback.current
    var input           by remember { mutableStateOf("") }
    var showSlash       by remember { mutableStateOf(false) }

    val slashCommands = listOf(
        "/clear" to "Clear conversation",
        "/system" to "Set system prompt",
        "/model" to "Show current model",
        "/temp" to "Show temperature",
        "/help" to "Show help",
    )

    // Auto scroll to bottom
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                title = {
                    Column {
                        Text(
                            settings.model.substringAfterLast("/").substringAfterLast("-").take(20),
                            style    = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        if (statusText.isNotEmpty()) {
                            Text(statusText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        } else {
                            ProviderLabel(settings.provider)
                        }
                    }
                },
                actions = {
                    if (generating) {
                        IconButton(onClick = { vm.stopGeneration(); haptic.performHapticFeedback(HapticFeedbackType.LongPress) }) {
                            Icon(Icons.Filled.StopCircle, "Stop", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp, color = MaterialTheme.colorScheme.background) {
                Column(modifier = Modifier.navigationBarsPadding().imePadding()) {
                    // Slash command suggestions
                    AnimatedVisibility(visible = showSlash) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(slashCommands.filter { (cmd, _) ->
                                input.isEmpty() || cmd.startsWith(input)
                            }) { (cmd, desc) ->
                                SuggestionChip(
                                    onClick = { input = cmd; showSlash = false },
                                    label   = { Text(cmd, style = MaterialTheme.typography.labelMedium) }
                                )
                            }
                        }
                        HorizontalDivider()
                    }
                    // Input row
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value            = input,
                            onValueChange    = { v ->
                                input     = v
                                showSlash = v.startsWith("/")
                            },
                            modifier         = Modifier.weight(1f),
                            placeholder      = { Text("Message…", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                            shape            = RoundedCornerShape(24.dp),
                            maxLines         = 5,
                            keyboardOptions  = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                            enabled          = !generating,
                        )
                        FilledIconButton(
                            onClick  = {
                                val text = input.trim()
                                if (text.isNotBlank() && !generating) {
                                    input = ""
                                    showSlash = false
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    vm.sendMessage(chatId, text)
                                }
                            },
                            modifier = Modifier.size(48.dp),
                            shape    = RoundedCornerShape(16.dp),
                            enabled  = input.isNotBlank() && !generating,
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, "Send")
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (messages.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.AutoAwesome, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                    Text("How can I help you?", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(
                state             = listState,
                modifier          = Modifier.fillMaxSize().padding(padding),
                contentPadding    = PaddingValues(horizontal = 12.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    MessageBubble(msg)
                }
                if (generating) {
                    item { ThinkingIndicator() }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(msg: MessageEntity) {
    val isUser   = msg.role == "user"
    val context  = LocalContext.current
    var showMenu by remember { mutableStateOf(false) }
    val haptic   = LocalHapticFeedback.current

    Row(
        modifier             = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        if (!isUser) {
            // AI avatar
            Surface(
                shape    = CircleShape,
                color    = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(32.dp).align(Alignment.Bottom)
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.AutoAwesome, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.width(8.dp))
        }

        Box {
            Surface(
                onClick   = { },
                onLongClick = { showMenu = true; haptic.performHapticFeedback(HapticFeedbackType.LongPress) },
                shape     = RoundedCornerShape(
                    topStart    = if (isUser) 18.dp else 4.dp,
                    topEnd      = if (isUser) 4.dp  else 18.dp,
                    bottomStart = 18.dp,
                    bottomEnd   = 18.dp
                ),
                color     = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                modifier  = Modifier.widthIn(max = 300.dp),
                shadowElevation = if (isUser) 0.dp else 1.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    if (msg.content.contains("```")) {
                        CodeBlock(msg.content)
                    } else {
                        Text(
                            text  = msg.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (msg.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                            lineHeight = 22.sp
                        )
                    }
                }
            }

            // Context menu
            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                DropdownMenuItem(
                    text         = { Text("Copy") },
                    leadingIcon  = { Icon(Icons.Filled.ContentCopy, null) },
                    onClick      = {
                        val clip = ClipData.newPlainText("text", msg.content)
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                        showMenu = false
                    }
                )
            }
        }
    }
}

@Composable
private fun CodeBlock(content: String) {
    val context = LocalContext.current
    Column {
        content.split("```").forEachIndexed { i, part ->
            if (i % 2 == 0) {
                if (part.isNotBlank()) Text(part.trim(), style = MaterialTheme.typography.bodyMedium)
            } else {
                val lines = part.lines()
                val lang  = lines.firstOrNull()?.trim() ?: ""
                val code  = if (lang.isNotEmpty()) lines.drop(1).joinToString("\n") else part
                Surface(
                    shape    = RoundedCornerShape(8.dp),
                    color    = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(lang.ifEmpty { "code" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            IconButton(
                                onClick  = {
                                    val clip = ClipData.newPlainText("code", code.trim())
                                    (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Filled.ContentCopy, "Copy code", modifier = Modifier.size(14.dp))
                            }
                        }
                        HorizontalDivider(thickness = 0.5.dp)
                        Text(
                            code.trim(),
                            modifier   = Modifier.padding(12.dp),
                            fontFamily = FontFamily.Monospace,
                            style      = MaterialTheme.typography.bodySmall,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ThinkingIndicator() {
    Row(
        horizontalArrangement = Arrangement.Start,
        verticalAlignment     = Alignment.CenterVertically,
        modifier              = Modifier.padding(vertical = 4.dp)
    ) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(32.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.AutoAwesome, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            }
        }
        Spacer(Modifier.width(8.dp))
        Surface(shape = RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(3) { i ->
                    val scale by animateFloatAsState(
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            androidx.compose.animation.core.keyframes {
                                durationMillis = 900
                                0.6f at 0 + i * 150
                                1.0f at 300 + i * 150
                                0.6f at 600 + i * 150
                            }
                        ), label = "dot$i"
                    )
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = scale))
                    )
                }
            }
        }
    }
}

@Composable
private fun ProviderLabel(provider: String) {
    val label = when (provider) {
        "groq"       -> "Groq"
        "openai"     -> "OpenAI"
        "anthropic"  -> "Anthropic"
        "deepseek"   -> "DeepSeek"
        "openrouter" -> "OpenRouter"
        else         -> "Gemini"
    }
    Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

private val Float.sp: TextUnit get() = this.sp
