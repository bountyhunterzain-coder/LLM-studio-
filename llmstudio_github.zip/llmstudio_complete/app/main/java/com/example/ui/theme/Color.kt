package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ── Brand ───────────────────────────────────────────────────
val BrandPurple      = Color(0xFF6D28D9)
val BrandPurpleLight = Color(0xFF7C3AED)
val BrandPurplePale  = Color(0xFFF0EBFF)
val BrandPurpleDark  = Color(0xFFA78BFA)

// ── Light Theme ─────────────────────────────────────────────
val LightBackground  = Color(0xFFFFFFFF)
val LightSurface     = Color(0xFFF9FAFB)
val LightSurface2    = Color(0xFFF3F4F6)
val LightBorder      = Color(0xFFE5E7EB)
val LightDivider     = Color(0xFFF3F4F6)
val LightTextMain    = Color(0xFF111827)
val LightTextSub     = Color(0xFF6B7280)
val LightTextHint    = Color(0xFF9CA3AF)
val LightUserBubble  = Color(0xFFF0EBFF)
val LightAiBubble    = Color(0xFFFFFFFF)
val LightCard        = Color(0xFFFFFFFF)
val LightNavBar      = Color(0xFFFFFFFF)

// ── Dark Theme ──────────────────────────────────────────────
val DarkBackground   = Color(0xFF0A0A0F)
val DarkSurface      = Color(0xFF131318)
val DarkSurface2     = Color(0xFF1C1C25)
val DarkBorder       = Color(0xFF2A2A35)
val DarkDivider      = Color(0xFF1E1E28)
val DarkTextMain     = Color(0xFFECECF4)
val DarkTextSub      = Color(0xFF9090A8)
val DarkTextHint     = Color(0xFF5C5C70)
val DarkUserBubble   = Color(0xFF2D2442)
val DarkAiBubble     = Color(0xFF1C1C25)
val DarkCard         = Color(0xFF1C1C25)
val DarkNavBar       = Color(0xFF131318)

// ── Semantic ────────────────────────────────────────────────
val ColorSuccess     = Color(0xFF16A34A)
val ColorSuccessBg   = Color(0xFFF0FDF4)
val ColorError       = Color(0xFFDC2626)
val ColorErrorBg     = Color(0xFFFEF2F2)
val ColorWarning     = Color(0xFFD97706)
val ColorWarningBg   = Color(0xFFFFFBEB)
val ColorInfo        = Color(0xFF2563EB)
val ColorInfoBg      = Color(0xFFEFF6FF)

// ── Terminal ────────────────────────────────────────────────
val TermBg           = Color(0xFF0D1117)
val TermSurface      = Color(0xFF161B22)
val TermBorder       = Color(0xFF30363D)
val TermText         = Color(0xFFE6EDF3)
val TermDim          = Color(0xFF8B949E)
val TermCyan         = Color(0xFF79C0FF)
val TermGreen        = Color(0xFF7EE787)
val TermRed          = Color(0xFFFF7B72)
val TermYellow       = Color(0xFFE3B341)
val TermMagenta      = Color(0xFFD2A8FF)
val TermWhite        = Color(0xFFCDD9E5)
val TermPrompt       = Color(0xFF58A6FF)

// ── Provider Colors ─────────────────────────────────────────
val GroqColor        = Color(0xFFF55036)
val GeminiColor      = Color(0xFF4285F4)
val OpenAIColor      = Color(0xFF10A37F)
val AnthropicColor   = Color(0xFFD4A27F)
val DeepSeekColor    = Color(0xFF4A90E2)
val OpenRouterColor  = Color(0xFF6366F1)
