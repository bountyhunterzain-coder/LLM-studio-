package com.example.ui.screens.terminal

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.*
import com.example.ui.theme.*
import kotlinx.coroutines.*

// ── Data ─────────────────────────────────────────────────────

enum class TColor { DEFAULT, CMD, ERROR, SUCCESS, WARNING, INFO, SYSTEM, DIM, YELLOW, MAGENTA }

data class TLine(val text: String, val color: TColor = TColor.DEFAULT)

// ── Terminal State ────────────────────────────────────────────

class TerminalState {
    val lines = mutableStateListOf<TLine>()
    val cmdHistory = mutableStateListOf<String>()
    var histIdx by mutableStateOf(-1)

    init { printBanner() }

    fun printBanner() {
        lines += TLine("  ██╗     ██╗     ███╗   ███╗", TColor.MAGENTA)
        lines += TLine("  ██║     ██║     ████╗ ████║", TColor.MAGENTA)
        lines += TLine("  ██║     ██║     ██╔████╔██║", TColor.MAGENTA)
        lines += TLine("  ██║     ██║     ██║╚██╔╝██║", TColor.MAGENTA)
        lines += TLine("  ███████╗███████╗██║ ╚═╝ ██║", TColor.MAGENTA)
        lines += TLine("  ╚══════╝╚══════╝╚═╝     ╚═╝  Studio", TColor.MAGENTA)
        lines += TLine("")
        lines += TLine("  LLM Studio Terminal  v1.0.0  (Android ${Build.VERSION.RELEASE})", TColor.INFO)
        lines += TLine("  Type 'help' for commands  |  'llms help' for AI commands", TColor.DIM)
        lines += TLine("")
    }

    fun add(text: String, color: TColor = TColor.DEFAULT) { lines += TLine(text, color) }
    fun addMany(items: List<Pair<String, TColor>>) { items.forEach { (t, c) -> lines += TLine(t, c) } }
    fun clear() { lines.clear(); lines += TLine("Terminal cleared.", TColor.DIM) }

    fun saveCmd(cmd: String) {
        if (cmd.isNotBlank() && (cmdHistory.isEmpty() || cmdHistory.last() != cmd)) {
            cmdHistory += cmd
            if (cmdHistory.size > 200) cmdHistory.removeAt(0)
        }
        histIdx = -1
    }

    fun historyUp(): String {
        if (cmdHistory.isEmpty()) return ""
        histIdx = if (histIdx < 0) cmdHistory.size - 1 else maxOf(0, histIdx - 1)
        return if (histIdx in cmdHistory.indices) cmdHistory[histIdx] else ""
    }

    fun historyDown(): String {
        if (histIdx < 0) return ""
        histIdx++
        return if (histIdx in cmdHistory.indices) cmdHistory[histIdx] else run { histIdx = -1; "" }
    }
}

// ── Screen ────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen() {
    val context = LocalContext.current
    val scope   = rememberCoroutineScope()
    val state   = remember { TerminalState() }
    val list    = rememberLazyListState()
    var input   by remember { mutableStateOf("") }
    var busy    by remember { mutableStateOf(false) }

    // Auto scroll
    LaunchedEffect(state.lines.size) {
        if (state.lines.isNotEmpty()) list.animateScrollToItem(state.lines.size - 1)
    }

    fun run(rawCmd: String) {
        val cmd = rawCmd.trim()
        if (cmd.isBlank()) return
        state.saveCmd(cmd)
        state.add("$ $cmd", TColor.CMD)
        input = ""
        busy = true
        scope.launch(Dispatchers.IO) {
            executeCommand(cmd, state) { busy = false }
        }
    }

    Scaffold(
        topBar = {
            Surface(color = TermBg) {
                Row(
                    modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(shape = RoundedCornerShape(6.dp), color = TermSurface) {
                            Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Surface(shape = androidx.compose.foundation.shape.CircleShape, color = Color(0xFFFF5F56), modifier = Modifier.size(10.dp)) {}
                                Surface(shape = androidx.compose.foundation.shape.CircleShape, color = Color(0xFFFFBD2E), modifier = Modifier.size(10.dp)) {}
                                Surface(shape = androidx.compose.foundation.shape.CircleShape, color = Color(0xFF27C93F), modifier = Modifier.size(10.dp)) {}
                            }
                        }
                        Text("Terminal", fontFamily = FontFamily.Monospace, color = TermText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (busy) {
                            CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 2.dp, color = TermGreen)
                        }
                    }
                    Row {
                        IconButton(onClick = { state.clear() }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Delete, "Clear", tint = TermDim, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { scope.launch { run("help") } }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Help, "Help", tint = TermDim, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(TermBg)
                .padding(padding)
        ) {
            // Output area
            LazyColumn(
                state          = list,
                modifier       = Modifier.weight(1f).padding(horizontal = 12.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(state.lines) { line ->
                    val color = when (line.color) {
                        TColor.CMD     -> TermCyan
                        TColor.ERROR   -> TermRed
                        TColor.SUCCESS -> TermGreen
                        TColor.WARNING -> TermYellow
                        TColor.INFO    -> TermCyan
                        TColor.SYSTEM  -> TermMagenta
                        TColor.DIM     -> TermDim
                        TColor.YELLOW  -> TermYellow
                        TColor.MAGENTA -> TermMagenta
                        else           -> TermText
                    }
                    Text(
                        text       = line.text,
                        color      = color,
                        fontFamily = FontFamily.Monospace,
                        fontSize   = 13.sp,
                        lineHeight = 19.sp,
                        modifier   = Modifier.fillMaxWidth()
                    )
                }
            }

            // Input bar
            Surface(color = TermSurface) {
                Column {
                    HorizontalDivider(color = TermBorder, thickness = 0.5.dp)
                    Row(
                        modifier            = Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment   = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // History nav
                        IconButton(onClick = { input = state.historyUp() }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Filled.KeyboardArrowUp, "History up", tint = TermDim, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { input = state.historyDown() }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Filled.KeyboardArrowDown, "History down", tint = TermDim, modifier = Modifier.size(16.dp))
                        }

                        // Prompt + input
                        Text("$", color = TermPrompt, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        BasicTextField(
                            value         = input,
                            onValueChange = { input = it },
                            modifier      = Modifier.weight(1f),
                            textStyle     = TextStyle(color = TermText, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                            cursorBrush   = SolidColor(TermGreen),
                            singleLine    = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = KeyboardActions(onGo = { if (!busy) run(input) }),
                        )

                        // Quick action buttons
                        IconButton(onClick = { if (!busy) run(input) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Send, "Run", tint = if (input.isNotBlank()) TermGreen else TermDim, modifier = Modifier.size(16.dp))
                        }
                    }
                    // Tab shortcuts
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp).padding(bottom = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("help", "llms help", "clear", "ls", "llms models", "apt update").forEach { quick ->
                            QuickBtn(quick) { run(quick) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickBtn(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape   = RoundedCornerShape(4.dp),
        color   = TermSurface,
        border  = androidx.compose.foundation.BorderStroke(0.5.dp, TermBorder)
    ) {
        Text(
            label,
            modifier   = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            fontFamily = FontFamily.Monospace,
            color      = TermDim,
            fontSize   = 11.sp
        )
    }
}

// ── Command Engine ────────────────────────────────────────────

private suspend fun executeCommand(cmd: String, state: TerminalState, done: () -> Unit) {
    val parts   = cmd.trim().split(" ")
    val base    = parts[0].lowercase()
    val args    = parts.drop(1)

    when {
        // ── Built-in ─────────────────────────────────────────
        base == "help" -> showHelp(state)
        base in listOf("clear", "cls") -> withContext(Dispatchers.Main) { state.clear() }
        base == "date" -> state.add(java.util.Date().toString())
        base == "whoami" -> state.add("root")
        base == "pwd" -> state.add("/data/user/0/com.aistudio.llmstudio.xkjs/files")
        base == "echo" -> state.add(args.joinToString(" "))
        base == "history" -> {
            state.add("Command history:", TColor.INFO)
            state.cmdHistory.takeLast(20).forEachIndexed { i, c -> state.add("  ${i + 1}. $c", TColor.DIM) }
        }
        base == "uname" -> {
            if ("-a" in args) state.add("Linux android ${Build.VERSION.RELEASE} #1 SMP PREEMPT arm64 GNU/Linux")
            else state.add("Linux")
        }
        base == "free" -> {
            val rt    = Runtime.getRuntime()
            val total = rt.totalMemory() / 1024 / 1024
            val free  = rt.freeMemory()  / 1024 / 1024
            val used  = total - free
            state.add("              total        used        free", TColor.DIM)
            state.add("Mem:       ${total}MB      ${used}MB      ${free}MB")
        }
        base == "df" -> {
            state.add("Filesystem      Size  Used Avail Use%", TColor.DIM)
            state.add("/data           64G   18G   46G  28%")
            state.add("/storage        64G   18G   46G  28%")
        }
        base == "ls" -> {
            val path = args.firstOrNull() ?: "."
            state.add("models/     logs/     exports/     cache/     settings.json", TColor.SUCCESS)
        }
        base == "cat" -> {
            val file = args.firstOrNull() ?: ""
            when {
                file == "settings.json" -> state.add("""{"provider":"gemini","model":"gemini-2.5-flash","temperature":0.7}""")
                file.endsWith(".log")   -> state.add("[Log file — no recent entries]", TColor.DIM)
                file.isNotEmpty()       -> state.add("cat: $file: No such file or directory", TColor.ERROR)
                else                    -> state.add("Usage: cat <filename>", TColor.WARNING)
            }
        }
        base == "python3" || base == "python" -> {
            if (args.isEmpty()) state.add("Python 3.11.6 (Android)  Type 'exit()' to quit.")
            else {
                state.add("Running ${args.first()}…", TColor.INFO)
                delay(800)
                state.add("Output: [Script executed via Android Python runtime]", TColor.SUCCESS)
            }
        }
        base == "pip3" || base == "pip" -> simulatePip(args, state)

        // ── apt ─────────────────────────────────────────────
        base == "apt" || base == "apt-get" -> simulateApt(args, state)

        // ── llms commands ────────────────────────────────────
        base == "llms" -> handleLlms(args, state)

        // ── setup wizard ─────────────────────────────────────
        base == "setup" -> runSetup(state)

        // ── Real shell (Android sh) ───────────────────────────
        else -> runShell(cmd, state)
    }

    withContext(Dispatchers.Main) {
        done()
        state.add("")
    }
}

private suspend fun showHelp(state: TerminalState) {
    state.addMany(listOf(
        "┌─────────────────────────────────────────────┐" to TColor.DIM,
        "│         LLM Studio — Built-in Commands      │" to TColor.INFO,
        "└─────────────────────────────────────────────┘" to TColor.DIM,
        "" to TColor.DEFAULT,
        "System Commands:" to TColor.YELLOW,
        "  help              This help message" to TColor.DEFAULT,
        "  clear / cls       Clear terminal" to TColor.DEFAULT,
        "  date              Current date & time" to TColor.DEFAULT,
        "  uname [-a]        System info" to TColor.DEFAULT,
        "  whoami            Current user" to TColor.DEFAULT,
        "  pwd               Working directory" to TColor.DEFAULT,
        "  ls [path]         List files" to TColor.DEFAULT,
        "  cat <file>        Read file" to TColor.DEFAULT,
        "  echo <text>       Print text" to TColor.DEFAULT,
        "  free              Memory usage" to TColor.DEFAULT,
        "  df                Disk usage" to TColor.DEFAULT,
        "  history           Command history" to TColor.DEFAULT,
        "" to TColor.DEFAULT,
        "Package Management:" to TColor.YELLOW,
        "  apt update         Update package list" to TColor.DEFAULT,
        "  apt install <pkg>  Install package" to TColor.DEFAULT,
        "  pip install <pkg>  Install Python package" to TColor.DEFAULT,
        "  python3 <script>   Run Python script" to TColor.DEFAULT,
        "" to TColor.DEFAULT,
        "AI Commands (llms):" to TColor.YELLOW,
        "  llms help          Show AI commands" to TColor.DEFAULT,
        "  llms models        List AI models" to TColor.DEFAULT,
        "  llms providers     List providers" to TColor.DEFAULT,
        "  llms stats         Performance stats" to TColor.DEFAULT,
        "  llms version       App version" to TColor.DEFAULT,
        "" to TColor.DEFAULT,
        "Misc:" to TColor.YELLOW,
        "  setup              First-time setup wizard" to TColor.DEFAULT,
        "" to TColor.DEFAULT,
        "Tip: Use ↑/↓ buttons for command history" to TColor.DIM,
    ))
}

private suspend fun handleLlms(args: List<String>, state: TerminalState) {
    val sub = args.firstOrNull()?.lowercase() ?: "help"
    when (sub) {
        "help" -> state.addMany(listOf(
            "┌─────────────────────────────────────────────┐" to TColor.DIM,
            "│          LLM Studio — AI Commands           │" to TColor.INFO,
            "└─────────────────────────────────────────────┘" to TColor.DIM,
            "" to TColor.DEFAULT,
            "  llms models              List installed models" to TColor.DEFAULT,
            "  llms providers           List AI providers" to TColor.DEFAULT,
            "  llms stats               Performance & usage stats" to TColor.DEFAULT,
            "  llms version             App version info" to TColor.DEFAULT,
            "  llms clear               Clear all conversations" to TColor.DEFAULT,
            "  llms benchmark           Run speed test" to TColor.DEFAULT,
            "  llms export              Export all conversations" to TColor.DEFAULT,
            "  llms info                System & AI info" to TColor.DEFAULT,
            "" to TColor.DEFAULT,
        ))
        "models" -> {
            state.add("Local GGUF Models:", TColor.YELLOW)
            state.add("  ● llama-3.2-1b-instruct-Q4_K_M.gguf   [700MB]  Loaded", TColor.SUCCESS)
            state.add("  ○ phi-3.5-mini-instruct-Q4_K_M.gguf  [2.2GB]  Not loaded", TColor.DIM)
            state.add("  ○ gemma-2-2b-it-Q4_K_M.gguf          [1.6GB]  Not loaded", TColor.DIM)
            state.add("")
            state.add("Cloud Models:", TColor.YELLOW)
            state.add("  ✓ gemini-2.5-flash    (Gemini — Free)", TColor.SUCCESS)
            state.add("  ✓ llama-3.1-8b-instant (Groq — Free)", TColor.SUCCESS)
            state.add("  ○ gpt-4o-mini         (OpenAI — Paid)", TColor.DIM)
            state.add("  ○ claude-haiku         (Anthropic — Paid)", TColor.DIM)
        }
        "providers" -> {
            state.add("Available Providers:", TColor.YELLOW)
            state.add("  Provider          Status    Free Tier", TColor.DIM)
            state.add("  ─────────────────────────────────────", TColor.DIM)
            state.add("  gemini            ✓ Ready   Yes (limited)", TColor.SUCCESS)
            state.add("  groq              ✓ Ready   Yes (generous)", TColor.SUCCESS)
            state.add("  openrouter        ✓ Ready   Yes (some models)", TColor.SUCCESS)
            state.add("  openai            ○ Needs key  No", TColor.WARNING)
            state.add("  deepseek          ○ Needs key  No (cheap)", TColor.WARNING)
            state.add("  anthropic         ○ Needs key  No", TColor.WARNING)
        }
        "stats" -> {
            val rt = Runtime.getRuntime()
            val mem = (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024
            state.addMany(listOf(
                "Performance Stats:" to TColor.YELLOW,
                "  RAM Used     : ${mem}MB" to TColor.DEFAULT,
                "  CPU Cores    : ${rt.availableProcessors()}" to TColor.DEFAULT,
                "  Android      : ${Build.VERSION.RELEASE}" to TColor.DEFAULT,
                "  App Version  : 1.0.0" to TColor.DEFAULT,
                "  DB Status    : OK" to TColor.SUCCESS,
                "  Model Status : Ready" to TColor.SUCCESS,
            ))
        }
        "version" -> state.addMany(listOf(
            "LLM Studio v1.0.0" to TColor.INFO,
            "  Build   : Release" to TColor.DEFAULT,
            "  Android : ${Build.VERSION.RELEASE}" to TColor.DEFAULT,
            "  Device  : ${Build.MANUFACTURER} ${Build.MODEL}" to TColor.DEFAULT,
        ))
        "benchmark" -> {
            state.add("Running benchmark…", TColor.INFO)
            delay(500)
            state.add("  Testing network latency…", TColor.DIM)
            delay(800)
            state.add("  Groq API     : ~320ms average", TColor.SUCCESS)
            state.add("  Gemini API   : ~580ms average", TColor.SUCCESS)
            state.add("  Local (1B)   : ~950ms first token", TColor.SUCCESS)
            state.add("")
            state.add("Benchmark complete. ✓", TColor.SUCCESS)
        }
        "info" -> {
            state.addMany(listOf(
                "System Info:" to TColor.YELLOW,
                "  Device       : ${Build.MANUFACTURER} ${Build.MODEL}" to TColor.DEFAULT,
                "  Android      : ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})" to TColor.DEFAULT,
                "  CPU ABI      : ${Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64"}" to TColor.DEFAULT,
                "  RAM          : ${Runtime.getRuntime().totalMemory() / 1024 / 1024}MB JVM" to TColor.DEFAULT,
                "  App          : LLM Studio v1.0.0" to TColor.DEFAULT,
            ))
        }
        else -> state.add("Unknown llms command: $sub. Try 'llms help'", TColor.ERROR)
    }
}

private suspend fun simulateApt(args: List<String>, state: TerminalState) {
    val sub = args.firstOrNull()?.lowercase() ?: ""
    when (sub) {
        "update" -> {
            state.add("Get:1 https://archive.ubuntu.com/ubuntu focal InRelease [265 kB]", TColor.DEFAULT)
            delay(400)
            state.add("Get:2 https://archive.ubuntu.com/ubuntu focal-updates InRelease [114 kB]", TColor.DEFAULT)
            delay(300)
            state.add("Get:3 https://archive.ubuntu.com/ubuntu focal-security InRelease [114 kB]", TColor.DEFAULT)
            delay(500)
            state.add("Reading package lists... Done", TColor.DEFAULT)
            state.add("Building dependency tree... Done", TColor.DEFAULT)
            state.add("${state.cmdHistory.size + 42} packages can be upgraded.", TColor.INFO)
        }
        "upgrade" -> {
            state.add("Calculating upgrade... Done", TColor.DEFAULT)
            delay(300)
            state.add("0 upgraded, 0 newly installed, 0 to remove.", TColor.SUCCESS)
        }
        "install" -> {
            val pkg = args.drop(1).firstOrNull() ?: ""
            if (pkg.isEmpty()) { state.add("apt install: package name required", TColor.ERROR); return }
            aptInstall(pkg, state)
        }
        "remove", "purge" -> {
            val pkg = args.drop(1).firstOrNull() ?: ""
            state.add("Removing $pkg …", TColor.WARNING)
            delay(500)
            state.add("Purging configuration files for $pkg …", TColor.DEFAULT)
            delay(200)
            state.add("$pkg removed successfully.", TColor.SUCCESS)
        }
        "list" -> {
            state.add("Listing installed packages:", TColor.DIM)
            listOf("python3 3.11.6", "python3-pip 23.3", "curl 7.88.1", "wget 1.21.3").forEach {
                state.add("  $it [installed]", TColor.SUCCESS)
            }
        }
        else -> {
            state.add("apt: command not found: $sub", TColor.ERROR)
            state.add("Usage: apt [update|upgrade|install|remove|list] [package]", TColor.DIM)
        }
    }
}

private suspend fun aptInstall(pkg: String, state: TerminalState) {
    val pkgMap = mapOf(
        "python3"              to "python3 3.11.6-1",
        "python3-pip"          to "python3-pip 23.3.1",
        "python3-dev"          to "python3-dev 3.11.6",
        "git"                  to "git 2.39.2",
        "curl"                 to "curl 7.88.1",
        "wget"                 to "wget 1.21.3",
        "ffmpeg"               to "ffmpeg 5.1.2",
        "nodejs"               to "nodejs 18.19.0",
        "npm"                  to "npm 9.6.7",
        "htop"                 to "htop 3.2.2",
        "vim"                  to "vim 9.0",
        "nano"                 to "nano 6.2",
        "unzip"                to "unzip 6.0",
        "zip"                  to "zip 3.0",
        "tmux"                 to "tmux 3.3a",
        "screen"               to "screen 4.9.0",
        "jq"                   to "jq 1.6",
        "build-essential"      to "build-essential 12.9",
        "cmake"                to "cmake 3.25.1",
        "libssl-dev"           to "libssl-dev 3.0.2",
        "python3-transformers" to "python3-transformers 4.36.2 (via pip)",
        "python3-torch"        to "python3-torch 2.1.2 (via pip)",
        "python3-numpy"        to "python3-numpy 1.26.3 (via pip)",
    )
    val info = pkgMap[pkg] ?: pkg

    state.add("Reading package lists... Done", TColor.DEFAULT)
    delay(200)
    state.add("Building dependency tree... Done", TColor.DEFAULT)
    delay(150)
    state.add("The following NEW packages will be installed:", TColor.DEFAULT)
    state.add("  $pkg", TColor.INFO)
    state.add("0 upgraded, 1 newly installed, 0 to remove and 0 not upgraded.", TColor.DEFAULT)
    state.add("Need to get ${(50..500).random()} kB of archives.", TColor.DEFAULT)
    state.add("Do you want to continue? [Y/n] Y", TColor.DIM)
    delay(100)
    state.add("Get:1 https://archive.ubuntu.com/ubuntu focal/main $pkg ${info.substringAfter(pkg).trim()} [${(50..500).random()} kB]", TColor.DEFAULT)
    delay(600)
    state.add("Fetched ${(50..500).random()} kB in 0s (${(200..900).random()} kB/s)", TColor.DEFAULT)
    delay(100)
    state.add("Selecting previously unselected package $pkg.", TColor.DEFAULT)
    delay(150)
    state.add("(Reading database ... ${(40000..60000).random()} files and directories currently installed.)", TColor.DIM)
    delay(200)
    state.add("Preparing to unpack .../packages/$pkg.deb ...", TColor.DEFAULT)
    delay(200)
    state.add("Unpacking $info ...", TColor.DEFAULT)
    delay(300)
    state.add("Setting up $info ...", TColor.DEFAULT)
    delay(200)
    state.add("Processing triggers for man-db (2.11.2-2) ...", TColor.DIM)
    delay(100)
    state.add("✓ $pkg installed successfully.", TColor.SUCCESS)
}

private suspend fun simulatePip(args: List<String>, state: TerminalState) {
    val sub = args.firstOrNull()?.lowercase() ?: ""
    if (sub != "install") {
        runShell("pip " + args.joinToString(" "), state); return
    }
    val pkg = args.drop(1).firstOrNull() ?: run {
        state.add("pip install: package name required", TColor.ERROR); return
    }

    val versions = mapOf(
        "requests"      to "2.31.0",
        "numpy"         to "1.26.3",
        "pandas"        to "2.1.4",
        "torch"         to "2.1.2",
        "transformers"  to "4.36.2",
        "scikit-learn"  to "1.3.2",
        "openai"        to "1.6.1",
        "anthropic"     to "0.8.1",
        "langchain"     to "0.1.0",
        "pillow"        to "10.2.0",
        "matplotlib"    to "3.8.2",
        "flask"         to "3.0.0",
        "fastapi"       to "0.108.0",
        "httpx"         to "0.26.0",
        "tqdm"          to "4.66.1",
        "pydantic"      to "2.5.3",
    )
    val version = versions[pkg] ?: "${(1..4).random()}.${(0..9).random()}.${(0..9).random()}"
    val sizeMb  = (0.1..15.0).let { pkg.length.toDouble() + 2.5 }

    state.add("Collecting $pkg", TColor.DEFAULT)
    delay(300)
    state.add("  Downloading ${pkg}-${version}-py3-none-any.whl (${String.format("%.1f", sizeMb)} MB)", TColor.DEFAULT)

    // Fake progress bar
    val bar = "━".repeat(40)
    state.add("     $bar ${String.format("%.1f", sizeMb)}/${String.format("%.1f", sizeMb)} MB", TColor.SUCCESS)
    delay(700)
    state.add("Collecting dependencies for $pkg", TColor.DIM)
    delay(400)
    state.add("Installing collected packages: $pkg", TColor.DEFAULT)
    delay(400)
    state.add("Successfully installed $pkg-$version", TColor.SUCCESS)
}

private suspend fun runSetup(state: TerminalState) {
    state.addMany(listOf(
        "┌─────────────────────────────────────────────┐" to TColor.DIM,
        "│         LLM Studio — First-Time Setup       │" to TColor.INFO,
        "└─────────────────────────────────────────────┘" to TColor.DIM,
        "" to TColor.DEFAULT,
        "Step 1/4  Checking system requirements…" to TColor.INFO,
    ))
    delay(600)
    state.add("  ✓ Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})", TColor.SUCCESS)
    state.add("  ✓ ${Runtime.getRuntime().availableProcessors()} CPU cores available", TColor.SUCCESS)
    state.add("  ✓ ${Runtime.getRuntime().totalMemory() / 1024 / 1024}MB JVM memory", TColor.SUCCESS)
    delay(400)
    state.add("")
    state.add("Step 2/4  Setting up directories…", TColor.INFO)
    delay(500)
    state.add("  ✓ models/     created", TColor.SUCCESS)
    state.add("  ✓ logs/       created", TColor.SUCCESS)
    state.add("  ✓ exports/    created", TColor.SUCCESS)
    delay(300)
    state.add("")
    state.add("Step 3/4  Checking AI providers…", TColor.INFO)
    delay(600)
    state.add("  ✓ Gemini API     reachable (free tier)", TColor.SUCCESS)
    state.add("  ✓ Groq API       reachable (free tier)", TColor.SUCCESS)
    state.add("  ✓ OpenRouter     reachable (free models)", TColor.SUCCESS)
    delay(400)
    state.add("")
    state.add("Step 4/4  Finalizing…", TColor.INFO)
    delay(700)
    state.add("  ✓ Database initialized", TColor.SUCCESS)
    state.add("  ✓ Settings loaded", TColor.SUCCESS)
    state.add("")
    state.addMany(listOf(
        "══════════════════════════════════════════════" to TColor.DIM,
        "  Setup complete! LLM Studio is ready." to TColor.SUCCESS,
        "" to TColor.DEFAULT,
        "  Next steps:" to TColor.YELLOW,
        "  1. Go to Settings → API Keys and add your keys" to TColor.DEFAULT,
        "  2. Or use free providers: Gemini, Groq, OpenRouter" to TColor.DEFAULT,
        "  3. Start chatting from the Chats tab" to TColor.DEFAULT,
        "══════════════════════════════════════════════" to TColor.DIM,
    ))
}

private suspend fun runShell(cmd: String, state: TerminalState) {
    try {
        val proc   = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(false).start()
        val outJob = CoroutineScope(Dispatchers.IO).launch {
            proc.inputStream.bufferedReader().forEachLine { line ->
                runBlocking(Dispatchers.Main) { state.add(line) }
            }
        }
        val errJob = CoroutineScope(Dispatchers.IO).launch {
            proc.errorStream.bufferedReader().forEachLine { line ->
                runBlocking(Dispatchers.Main) { state.add(line, TColor.ERROR) }
            }
        }
        withTimeout(30_000) { proc.waitFor() }
        outJob.join(); errJob.join()
        val code = proc.exitValue()
        if (code != 0) state.add("[Exit code: $code]", TColor.DIM)
    } catch (e: Exception) {
        state.add("Error: ${e.message ?: "Command failed"}", TColor.ERROR)
    }
}
