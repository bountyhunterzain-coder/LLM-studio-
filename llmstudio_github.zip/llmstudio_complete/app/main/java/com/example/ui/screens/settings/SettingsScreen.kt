package com.example.ui.screens.settings

import android.app.Application
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)
    val settings = repo.settings

    fun save(s: AppSettings) = viewModelScope.launch { repo.save(s) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: SettingsViewModel = viewModel()) {
    val settings by vm.settings.collectAsState(initial = AppSettings())
    val context  = LocalContext.current
    val scroll   = rememberScrollState()
    var exportMsg by remember { mutableStateOf("") }

    fun update(block: AppSettings.() -> AppSettings) = vm.save(settings.block())

    if (exportMsg.isNotEmpty()) {
        LaunchedEffect(exportMsg) {
            kotlinx.coroutines.delay(3000)
            exportMsg = ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Settings, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                        Text("Settings", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(scroll)) {

            // ── AI Provider ─────────────────────────────────────────
            SectionHeader("AI Provider")
            Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Providers.all.forEach { prov ->
                    ProviderRow(
                        provider = prov,
                        selected = settings.provider == prov.id,
                        onClick  = { update { copy(provider = prov.id, model = prov.defaultModel) } }
                    )
                }
            }
            SectionDivider()

            // ── Model ────────────────────────────────────────────────
            SectionHeader("Model")
            val currentProv = Providers.get(settings.provider)
            Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                currentProv.models.forEach { modelId ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (settings.model == modelId) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .clickable { update { copy(model = modelId) } }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(modelId, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        if (settings.model == modelId) Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                }
            }
            SectionDivider()

            // ── API Keys ─────────────────────────────────────────────
            SectionHeader("API Keys")
            Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ApiKeyField("Gemini (free)", "AIza...", settings.geminiKey, Icons.Filled.Star)     { update { copy(geminiKey = it) } }
                ApiKeyField("Groq (free)",   "gsk_...", settings.groqKey, Icons.Filled.Bolt)       { update { copy(groqKey = it) } }
                ApiKeyField("OpenRouter",  "sk-or-...", settings.openRouterKey, Icons.Filled.Hub)  { update { copy(openRouterKey = it) } }
                ApiKeyField("OpenAI",        "sk-...",  settings.openAiKey, Icons.Filled.SmartToy) { update { copy(openAiKey = it) } }
                ApiKeyField("DeepSeek",      "sk-...",  settings.deepSeekKey, Icons.Filled.Psychology){ update { copy(deepSeekKey = it) } }
                ApiKeyField("Anthropic",  "sk-ant-...", settings.anthropicKey, Icons.Filled.Android){ update { copy(anthropicKey = it) } }
            }
            SectionDivider()

            // ── Generation ───────────────────────────────────────────
            SectionHeader("Generation")
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Temperature
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Temperature", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                            Text(String.format("%.1f", settings.temperature), modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Slider(value = settings.temperature, onValueChange = { update { copy(temperature = it) } }, valueRange = 0f..2f, steps = 19)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Precise", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Creative", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                // Max tokens
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Max Output Tokens", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                            Text("${settings.maxTokens}", modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Slider(value = settings.maxTokens.toFloat(), onValueChange = { update { copy(maxTokens = it.toInt()) } }, valueRange = 256f..8192f, steps = 30)
                }
            }
            SectionDivider()

            // ── System Prompt ─────────────────────────────────────────
            SectionHeader("System Prompt")
            OutlinedTextField(
                value         = settings.systemPrompt,
                onValueChange = { update { copy(systemPrompt = it) } },
                modifier      = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                shape         = RoundedCornerShape(12.dp),
                minLines      = 3,
                maxLines      = 6,
                placeholder   = { Text("You are a helpful assistant…") }
            )
            SectionDivider()

            // ── Appearance ───────────────────────────────────────────
            SectionHeader("Appearance")
            ToggleRow("Dark Mode", Icons.Outlined.DarkMode, settings.darkMode) { update { copy(darkMode = it) } }
            SectionDivider()

            // ── Data ─────────────────────────────────────────────────
            SectionHeader("Data")
            ActionRow("Export Conversations", Icons.Filled.FileDownload, Color(0xFF2563EB)) {
                kotlinx.coroutines.MainScope().launch {
                    val path = com.example.utils.ZipExporter.exportAppData(context)
                    exportMsg = if (path != null) "Exported to Downloads/${ path.substringAfterLast("/") }" else "Export failed"
                }
            }
            if (exportMsg.isNotEmpty()) {
                Text(exportMsg, modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            SectionDivider()

            // ── About ────────────────────────────────────────────────
            SectionHeader("About")
            InfoRow(Icons.Filled.Info, "Version", "1.0.0")
            InfoRow(Icons.Filled.Android, "Platform", "Android ${android.os.Build.VERSION.RELEASE}")
            InfoRow(Icons.Filled.DeviceHub, "Device", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ── Reusable Components ───────────────────────────────────────

@Composable
private fun SectionHeader(title: String) {
    Text(
        title.uppercase(),
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp).padding(top = 4.dp),
        style    = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color    = MaterialTheme.colorScheme.primary,
        letterSpacing = 0.8.sp
    )
}

@Composable
private fun SectionDivider() {
    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
}

@Composable
private fun ProviderRow(provider: ProviderInfo, selected: Boolean, onClick: () -> Unit) {
    val color = when (provider.id) {
        "groq"       -> Color(0xFFF55036)
        "openai"     -> Color(0xFF10A37F)
        "anthropic"  -> Color(0xFFD4A27F)
        "deepseek"   -> Color(0xFF4A90E2)
        "openrouter" -> Color(0xFF6366F1)
        else         -> Color(0xFF4285F4)
    }
    Surface(
        onClick = onClick,
        shape   = RoundedCornerShape(12.dp),
        color   = if (selected) color.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
        border  = androidx.compose.foundation.BorderStroke(if (selected) 1.5.dp else 0.8.dp, if (selected) color else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(shape = CircleShape, color = color.copy(alpha = 0.15f), modifier = Modifier.size(36.dp)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Cloud, null, tint = color, modifier = Modifier.size(18.dp))
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(provider.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                Text(
                    if (provider.isFree) "Free tier available" else "Paid",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (provider.isFree) Color(0xFF16A34A) else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (selected) Icon(Icons.Filled.CheckCircle, null, tint = color, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun ApiKeyField(label: String, hint: String, value: String, icon: ImageVector, onSave: (String) -> Unit) {
    var text    by remember(value) { mutableStateOf(value) }
    var visible by remember { mutableStateOf(false) }
    var saved   by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium)
        OutlinedTextField(
            value         = text,
            onValueChange = { text = it; saved = false },
            modifier      = Modifier.fillMaxWidth(),
            shape         = RoundedCornerShape(10.dp),
            placeholder   = { Text(hint, style = MaterialTheme.typography.bodySmall) },
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            leadingIcon   = { Icon(icon, null, modifier = Modifier.size(18.dp)) },
            trailingIcon  = {
                Row {
                    IconButton(onClick = { visible = !visible }, modifier = Modifier.size(40.dp)) {
                        Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { onSave(text); saved = true }, modifier = Modifier.size(40.dp)) {
                        Icon(
                            if (saved) Icons.Filled.CheckCircle else Icons.Filled.Save,
                            null,
                            tint     = if (saved) Color(0xFF16A34A) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            singleLine = true,
            colors     = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
            )
        )
    }
}

@Composable
private fun ToggleRow(title: String, icon: ImageVector, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        modifier  = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(34.dp)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(icon, null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(title, style = MaterialTheme.typography.bodyMedium)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun ActionRow(title: String, icon: ImageVector, color: Color, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        shape    = RoundedCornerShape(10.dp),
        color    = color.copy(alpha = 0.06f)
    ) {
        Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Text(title, style = MaterialTheme.typography.bodyMedium, color = color, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Filled.ChevronRight, null, tint = color.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(34.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(icon, null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
