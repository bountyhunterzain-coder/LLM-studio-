package com.example.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

// ── Gemini Models ────────────────────────────────────────────

@Serializable
data class GeminiRequest(
    val contents: List<GContent>,
    val systemInstruction: GContent? = null,
    val generationConfig: GGenerationConfig? = null
)

@Serializable
data class GContent(
    val role: String? = null,
    val parts: List<GPart>
)

@Serializable
data class GPart(val text: String? = null)

@Serializable
data class GGenerationConfig(
    val temperature: Double = 0.7,
    val maxOutputTokens: Int = 2048
)

@Serializable
data class GeminiResponse(
    val candidates: List<GCandidate>? = null
)

@Serializable
data class GCandidate(val content: GContent? = null)

// ── Groq / OpenAI Compatible Models ──────────────────────────

@Serializable
data class OAIChatRequest(
    val model: String,
    val messages: List<OAIMessage>,
    val temperature: Double = 0.7,
    val max_tokens: Int = 2048,
    val stream: Boolean = false
)

@Serializable
data class OAIMessage(val role: String, val content: String)

@Serializable
data class OAIChatResponse(val choices: List<OAIChoice>? = null)

@Serializable
data class OAIChoice(val message: OAIMessage? = null)

// ── Gemini API Interface ─────────────────────────────────────

interface GeminiApiService {
    @POST("v1beta/models/gemini-2.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

// ── OpenAI-Compatible Interface ──────────────────────────────

interface OAIApiService {
    @POST("chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: OAIChatRequest
    ): OAIChatResponse
}

// ── HTTP Client ──────────────────────────────────────────────

object HttpClient {
    val json = Json { ignoreUnknownKeys = true; isLenient = true }

    val okHttp: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun geminiService(): GeminiApiService = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttp)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()
        .create(GeminiApiService::class.java)

    fun oaiService(baseUrl: String): OAIApiService = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(okHttp)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()
        .create(OAIApiService::class.java)
}

// ── Provider Info ────────────────────────────────────────────

data class ProviderInfo(
    val id: String,
    val name: String,
    val baseUrl: String,
    val defaultModel: String,
    val models: List<String>,
    val isFree: Boolean,
    val requiresKey: Boolean,
    val keyHint: String = ""
)

object Providers {
    val all = listOf(
        ProviderInfo("gemini",     "Google Gemini",  "",                                    "gemini-2.5-flash",          listOf("gemini-2.5-flash","gemini-2.0-flash","gemini-1.5-pro"), true,  true,  "AIza..."),
        ProviderInfo("groq",       "Groq",           "https://api.groq.com/openai/v1/",     "llama-3.1-8b-instant",      listOf("llama-3.1-8b-instant","llama-3.3-70b-versatile","mixtral-8x7b-32768"), true, true, "gsk_..."),
        ProviderInfo("openrouter", "OpenRouter",     "https://openrouter.ai/api/v1/",       "meta-llama/llama-3.2-3b-instruct:free", listOf("meta-llama/llama-3.2-3b-instruct:free","deepseek/deepseek-r1:free","google/gemma-3-12b-it:free"), true, true, "sk-or-..."),
        ProviderInfo("openai",     "OpenAI",         "https://api.openai.com/v1/",          "gpt-4o-mini",               listOf("gpt-4o-mini","gpt-4o","gpt-3.5-turbo"), false, true, "sk-..."),
        ProviderInfo("deepseek",   "DeepSeek",       "https://api.deepseek.com/v1/",        "deepseek-chat",             listOf("deepseek-chat","deepseek-coder"), false, true, "sk-..."),
        ProviderInfo("anthropic",  "Anthropic",      "https://api.anthropic.com/v1/",       "claude-haiku-4-5-20251001", listOf("claude-haiku-4-5-20251001","claude-sonnet-4-6"), false, true, "sk-ant-..."),
    )
    fun get(id: String) = all.find { it.id == id } ?: all.first()
}

// ── Universal Chat Client ────────────────────────────────────

object AiClient {

    suspend fun chat(
        provider: String,
        model: String,
        apiKey: String,
        messages: List<MessageEntity>,
        systemPrompt: String = "You are a helpful, concise AI assistant.",
        temperature: Double = 0.7,
        maxTokens: Int = 2048
    ): String {
        return when (provider) {
            "gemini" -> chatGemini(model, apiKey, messages, systemPrompt, temperature, maxTokens)
            else     -> chatOAI(provider, model, apiKey, messages, systemPrompt, temperature, maxTokens)
        }
    }

    private suspend fun chatGemini(
        model: String,
        apiKey: String,
        messages: List<MessageEntity>,
        systemPrompt: String,
        temperature: Double,
        maxTokens: Int
    ): String {
        val contents = messages
            .filter { it.role != "system" }
            .map { msg ->
                GContent(
                    role  = if (msg.role == "user") "user" else "model",
                    parts = listOf(GPart(msg.content))
                )
            }
        val request = GeminiRequest(
            contents          = contents,
            systemInstruction = GContent(parts = listOf(GPart(systemPrompt))),
            generationConfig  = GGenerationConfig(temperature, maxTokens)
        )
        val usedModel = model.ifBlank { "gemini-2.5-flash" }
        val service   = Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(HttpClient.okHttp)
            .addConverterFactory(HttpClient.json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GeminiApiService::class.java)

        val resp = service.generateContent(apiKey, request)
        return resp.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            ?: "No response received."
    }

    private suspend fun chatOAI(
        provider: String,
        model: String,
        apiKey: String,
        messages: List<MessageEntity>,
        systemPrompt: String,
        temperature: Double,
        maxTokens: Int
    ): String {
        val info    = Providers.get(provider)
        val oaiMsgs = mutableListOf(OAIMessage("system", systemPrompt))
        messages.filter { it.role != "system" }.forEach { msg ->
            oaiMsgs.add(OAIMessage(if (msg.role == "user") "user" else "assistant", msg.content))
        }
        val request = OAIChatRequest(
            model       = model.ifBlank { info.defaultModel },
            messages    = oaiMsgs,
            temperature = temperature,
            max_tokens  = maxTokens,
        )
        val auth    = when (provider) {
            "anthropic" -> apiKey
            else        -> "Bearer $apiKey"
        }
        val service = HttpClient.oaiService(info.baseUrl)
        val resp    = service.chatCompletion(auth, request)
        return resp.choices?.firstOrNull()?.message?.content ?: "No response received."
    }
}
