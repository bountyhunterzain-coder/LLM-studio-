package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val title: String,
    val modelId: String    = "gemini-2.5-flash",
    val provider: String   = "gemini",
    val systemPrompt: String = "",
    val createdAt: Long    = System.currentTimeMillis(),
    val updatedAt: Long    = System.currentTimeMillis(),
    val messageCount: Int  = 0,
    val isPinned: Boolean  = false,
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val chatId: String,
    val role: String,          // "user" | "assistant" | "system"
    val content: String,
    val timestamp: Long        = System.currentTimeMillis(),
    val tokensUsed: Int        = 0,
    val provider: String       = "",
    val modelId: String        = "",
    val generationMs: Long     = 0L,
    val isError: Boolean       = false,
)
