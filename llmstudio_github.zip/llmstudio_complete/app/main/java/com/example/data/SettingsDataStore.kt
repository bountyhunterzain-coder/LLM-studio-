package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "llmstudio_settings")

object SettingsKeys {
    val PROVIDER       = stringPreferencesKey("provider")
    val MODEL          = stringPreferencesKey("model")
    val TEMPERATURE    = floatPreferencesKey("temperature")
    val MAX_TOKENS     = intPreferencesKey("max_tokens")
    val SYSTEM_PROMPT  = stringPreferencesKey("system_prompt")
    val DARK_MODE      = booleanPreferencesKey("dark_mode")
    val GEMINI_KEY     = stringPreferencesKey("key_gemini")
    val GROQ_KEY       = stringPreferencesKey("key_groq")
    val OPENAI_KEY     = stringPreferencesKey("key_openai")
    val OPENROUTER_KEY = stringPreferencesKey("key_openrouter")
    val DEEPSEEK_KEY   = stringPreferencesKey("key_deepseek")
    val ANTHROPIC_KEY  = stringPreferencesKey("key_anthropic")
}

data class AppSettings(
    val provider: String      = "gemini",
    val model: String         = "gemini-2.5-flash",
    val temperature: Float    = 0.7f,
    val maxTokens: Int        = 2048,
    val systemPrompt: String  = "You are a helpful, concise AI assistant.",
    val darkMode: Boolean     = false,
    val geminiKey: String     = "",
    val groqKey: String       = "",
    val openAiKey: String     = "",
    val openRouterKey: String = "",
    val deepSeekKey: String   = "",
    val anthropicKey: String  = "",
)

class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { prefs ->
            AppSettings(
                provider      = prefs[SettingsKeys.PROVIDER]       ?: "gemini",
                model         = prefs[SettingsKeys.MODEL]           ?: "gemini-2.5-flash",
                temperature   = prefs[SettingsKeys.TEMPERATURE]     ?: 0.7f,
                maxTokens     = prefs[SettingsKeys.MAX_TOKENS]      ?: 2048,
                systemPrompt  = prefs[SettingsKeys.SYSTEM_PROMPT]   ?: "You are a helpful, concise AI assistant.",
                darkMode      = prefs[SettingsKeys.DARK_MODE]       ?: false,
                geminiKey     = prefs[SettingsKeys.GEMINI_KEY]      ?: "",
                groqKey       = prefs[SettingsKeys.GROQ_KEY]        ?: "",
                openAiKey     = prefs[SettingsKeys.OPENAI_KEY]      ?: "",
                openRouterKey = prefs[SettingsKeys.OPENROUTER_KEY]  ?: "",
                deepSeekKey   = prefs[SettingsKeys.DEEPSEEK_KEY]    ?: "",
                anthropicKey  = prefs[SettingsKeys.ANTHROPIC_KEY]   ?: "",
            )
        }

    suspend fun save(settings: AppSettings) {
        context.dataStore.edit { prefs ->
            prefs[SettingsKeys.PROVIDER]       = settings.provider
            prefs[SettingsKeys.MODEL]          = settings.model
            prefs[SettingsKeys.TEMPERATURE]    = settings.temperature
            prefs[SettingsKeys.MAX_TOKENS]     = settings.maxTokens
            prefs[SettingsKeys.SYSTEM_PROMPT]  = settings.systemPrompt
            prefs[SettingsKeys.DARK_MODE]      = settings.darkMode
            prefs[SettingsKeys.GEMINI_KEY]     = settings.geminiKey
            prefs[SettingsKeys.GROQ_KEY]       = settings.groqKey
            prefs[SettingsKeys.OPENAI_KEY]     = settings.openAiKey
            prefs[SettingsKeys.OPENROUTER_KEY] = settings.openRouterKey
            prefs[SettingsKeys.DEEPSEEK_KEY]   = settings.deepSeekKey
            prefs[SettingsKeys.ANTHROPIC_KEY]  = settings.anthropicKey
        }
    }

    fun getKeyForProvider(settings: AppSettings, provider: String) = when (provider) {
        "gemini"     -> settings.geminiKey
        "groq"       -> settings.groqKey
        "openai"     -> settings.openAiKey
        "openrouter" -> settings.openRouterKey
        "deepseek"   -> settings.deepSeekKey
        "anthropic"  -> settings.anthropicKey
        else         -> ""
    }
}
