package com.example.utils

import android.content.Context
import android.os.Environment
import com.example.data.AppDatabase
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ZipExporter {

    suspend fun exportAppData(context: Context): String? {
        return try {
            val db       = AppDatabase.getDatabase(context)
            val dao      = db.chatDao()
            val chats    = db.chatDao().getRecentMessages(1000)
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val fileName = "llmstudio_export_$timestamp.zip"

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir.mkdirs()
            val zipFile = File(downloadsDir, fileName)

            ZipOutputStream(FileOutputStream(zipFile)).use { zip ->
                // Export info
                val info = """
                    LLM Studio Export
                    Generated: ${Date()}
                    App Version: 1.0.0
                """.trimIndent()
                zip.putNextEntry(ZipEntry("info.txt"))
                zip.write(info.toByteArray())
                zip.closeEntry()

                // Export recent messages as JSON
                val json = buildString {
                    append("[\n")
                    chats.forEachIndexed { i, msg ->
                        append("""  {"id":${msg.id},"chatId":"${msg.chatId}","role":"${msg.role}","content":${escapeJson(msg.content)},"timestamp":${msg.timestamp}}""")
                        if (i < chats.size - 1) append(",")
                        append("\n")
                    }
                    append("]")
                }
                zip.putNextEntry(ZipEntry("messages.json"))
                zip.write(json.toByteArray())
                zip.closeEntry()

                // Export settings placeholder
                zip.putNextEntry(ZipEntry("settings.json"))
                zip.write("""{"exported_at":"${Date()}","version":"1.0.0"}""".toByteArray())
                zip.closeEntry()
            }

            zipFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun escapeJson(text: String): String {
        return "\"" + text
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t") + "\""
    }
}
