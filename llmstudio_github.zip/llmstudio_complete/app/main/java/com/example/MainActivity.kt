package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.example.data.SettingsRepository
import com.example.ui.MainAppScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context  = LocalContext.current
            val repo     = remember { SettingsRepository(context) }
            val settings by repo.settings.collectAsState(
                initial  = com.example.data.AppSettings()
            )
            MyApplicationTheme(darkTheme = settings.darkMode) {
                MainAppScreen()
            }
        }
    }
}
